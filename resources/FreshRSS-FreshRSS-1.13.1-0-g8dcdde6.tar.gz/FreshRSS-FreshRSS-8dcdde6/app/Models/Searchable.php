<?php

interface FreshRSS_Searchable {

	public function searchById($id);
}
