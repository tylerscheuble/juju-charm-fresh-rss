<?php

class FreshRSS_TagDAOPGSQL extends FreshRSS_TagDAO {

	public function sqlIgnore() {
		return '';	//TODO
	}

}
