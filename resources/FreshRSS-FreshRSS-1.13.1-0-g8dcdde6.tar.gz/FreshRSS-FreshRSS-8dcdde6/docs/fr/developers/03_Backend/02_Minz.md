# Modèles

**TODO**

# Contrôleurs et actions

**TODO**

# Vues

**TODO**

# Routage

**TODO**

# Écriture des URL

**TODO**

# Internationalisation

**TODO**

# Comprendres les mécanismes internes

**TODO**
