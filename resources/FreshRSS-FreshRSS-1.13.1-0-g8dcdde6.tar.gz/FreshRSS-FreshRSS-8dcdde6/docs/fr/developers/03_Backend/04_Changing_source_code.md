# Accès à la base de données

**TODO**

# Écrire une action et sa vue associée

**TODO**

# Gestion de l'authentification

**TODO**

# Gestion des logs

**TODO**
