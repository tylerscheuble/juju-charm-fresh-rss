# Les fichiers .phtml

**TODO**

# Écrire une URL

**TODO**

# Afficher une icône

**TODO**

# Internationalisation

**TODO**
