# Ajouter un flux

**TODO**

# Import et export

**TODO**

# Utiliser le « bookmarklet »

Les « bookmarklets » sont de petits scripts que vous pouvez exécuter pour effectuer des tâches utiles ou frivoles. FreshRSS offre un signet ( « bookmark » ) pour s'abonner aux fils de nouvelles.

 1. Ouvrez "Gestion des abonnements".
 2. Cliquez sur "Outils d'abonnement".
 3. Glissez le bouton "S'abonner" dans la barre d'outils des signets ou cliquez droit et choisissez l'action "Lien vers les signets" de votre navigateur.

# Organisation des flux

**TODO**
