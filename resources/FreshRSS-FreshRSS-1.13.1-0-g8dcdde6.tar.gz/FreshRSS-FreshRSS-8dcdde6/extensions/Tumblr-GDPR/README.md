# Tumblr-GDPR

Needed for accessing [Tumblr](https://www.tumblr.com/) RSS feeds from the European Union:
bypass the [GPDR](https://en.wikipedia.org/wiki/General_Data_Protection_Regulation) check, implying consent.
