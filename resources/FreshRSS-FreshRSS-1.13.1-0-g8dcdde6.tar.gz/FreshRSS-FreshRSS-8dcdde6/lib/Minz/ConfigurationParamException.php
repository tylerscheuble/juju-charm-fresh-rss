<?php

class Minz_ConfigurationParamException extends Minz_ConfigurationException {
}
