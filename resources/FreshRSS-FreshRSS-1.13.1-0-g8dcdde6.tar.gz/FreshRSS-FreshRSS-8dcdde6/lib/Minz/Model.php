<?php
/**
 * MINZ - Copyright 2011 Marien Fressinaud
 * Sous licence AGPL3 <http://www.gnu.org/licenses/>
*/

/**
 * La classe Model représente un modèle de l'application (représentation MVC)
 */
class Minz_Model {

}
