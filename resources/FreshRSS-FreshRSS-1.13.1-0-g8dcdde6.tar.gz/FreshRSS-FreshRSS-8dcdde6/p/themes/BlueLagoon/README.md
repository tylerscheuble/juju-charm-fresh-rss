Blue Lagoon
=======

**C'est un cocktail (bis)! C'est la version plus "fresh" de [Screwdriver](https://github.com/misterair/Screwdriver). C'est... c'est... un thème pour l'agrégateur de flux RSS [FreshRSS](https://github.com/FreshRSS/FreshRSS/)**


En toute modestie, ce thème tue du Nyan Cat.

![screenshot](https://raw.githubusercontent.com/misterair/BlueLagoon/master/screenshot.png)


Installation
-----------------
1. Placez le dossier du thème dans ledossier /FreshRSS/p/themes/Screwdriver de votre FreshRSS;
2. Allez dans les paramètres d'Affichage et changez de thème;
3. Profitez de votre Blue Laggon sans modération!
4. Remontez les problèmes sur Github (*facultatif mais fortement apprécié*)



Blue Lagoon est distribué sous license AlcoholWare:
-----------------

« LICENCE ALCOHOLWARE » (Révision 42):

mister.air@gmail.com a créé ce fichier. Tant que vous conservez cet avertissement,

vous pouvez faire ce que vous voulez de ce truc. Si on se rencontre un jour et

que vous pensez que ce truc vaut le coup, vous pouvez me payer un verre (rempli) en retour.

*Mister aiR*






