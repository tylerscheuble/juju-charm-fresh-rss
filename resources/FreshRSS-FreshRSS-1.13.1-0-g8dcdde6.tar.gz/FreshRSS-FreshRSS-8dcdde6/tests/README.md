# FreshRSS tests

```sh
cd ./tests/
wget https://phar.phpunit.de/phpunit.phar
php phpunit.phar --bootstrap bootstrap.php
```
